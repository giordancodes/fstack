var React = require('react');
var ReactDOM = require('react-dom');

var CatApp = require('./components/cat_app');

// Include your React components like this:
// var MyComponent = require('components/my_component');

ReactDOM.render(<CatApp />, document.getElementById("placeholder"));
