var React = require('react');
var ReactDOM = require('react-dom');

// Include your React components like this:
// var MyComponent = require('components/my_component');

ReactDOM.render(<div>React Element goes here</div>, document.getElementById("placeholder"));
