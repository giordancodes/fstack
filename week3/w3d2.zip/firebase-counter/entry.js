var ReactDOM = require('react-dom');
var React = require('react');

var App = require('./components/app_split.js');

ReactDOM.render(<App />, document.getElementById('placeholder'));
