var React = require('react');

var Benefits = React.createClass({
  render: function() {
    return <div style={{'text-align': 'center'}}>
      <div className='row'>
        <div className='col-md-6'>
          <h1>
            <i className='glyphicon glyphicon-fire'></i> Amazing Feature 1
          </h1>
          <p>You wont believe how amazing this feature is..</p>
        </div>
        <div className='col-md-6'>
          <h1>
            <i className='glyphicon glyphicon-fire'></i> Amazing Feature 2
          </h1>
          <p>You wont believe how amazing this feature is..</p>
        </div>
      </div>
    </div>
  }
})

module.exports = Benefits;
