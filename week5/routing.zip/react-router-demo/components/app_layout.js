var React = require('react');

var AppLayout = React.createClass({
  render: function() {
    return <div>
    <nav className="navbar navbar-default">
      <div className="container-fluid">
        <div className="navbar-header">
          <a className="navbar-brand" href="#">
            Amazing Widget Co.
          </a>
        </div>

        <ul className="nav navbar-nav">
          <li><a href="/">Home</a></li>
          <li><a href="/benefits">Benefits</a></li>
          <li><a href="/pricing">Pricing</a></li>
        </ul>
      </div>
    </nav>

      {/* You'll need to include the 'current component' from React router here */}
    </div>
  }
})

module.exports = AppLayout;
