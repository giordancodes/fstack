var React = require('react');

var Home = React.createClass({
  render: function() {
    return <div className='jumbotron' style={{ 'padding' : '100px'}}>
      <h1>Amazing Widget Page</h1>
      <p className='lead'>This is the homepage of the best widget ever.</p>
    </div>
  }
})

module.exports = Home;
