var React = require('react');

var Pricing = React.createClass({
  render: function() {
    return <div>
      <div className='row'>
        <div className='col-md-4'>
          <h2>Starter</h2>
          <ul>
            <li>Benefit 1</li>
            <li>Benefit 2</li>
            <li>Benefit 3</li>
          </ul>
        </div>
        <div className='col-md-4'>
          <h2>Pro</h2>
          <ul>
            <li>Benefit 1</li>
            <li>Benefit 2</li>
            <li>Benefit 3</li>
          </ul>
        </div>
        <div className='col-md-4'>
          <h2>Enterprise</h2>
          <ul>
            <li>Benefit 1</li>
            <li>Benefit 2</li>
            <li>Benefit 3</li>
          </ul>
        </div>
      </div>
    </div>
  }
})

module.exports = Pricing;
