import { Router, Route, browserHistory } from 'react-router';
var React = require('react');
var ReactDOM = require('react-dom');

var Home = require('./components/home');
var Benefits = require('./components/benefits');
var Pricing = require('./components/pricing');

var AppLayout = require('./components/app_layout');


// Instructions

// 1. Add routing that maps the following URLs to components:
//   / - Home
//   /benefits - Benefits
//   /pricing - Pricing

// 2. Have all of the components render inside AppLayout (nest your
//    routes inside of it)

// 3. Modify AppLayout so it uses the <Link> component to navigate between
//    different routes

ReactDOM.render(<div>Add your routes here</div>, document.getElementById("placeholder"));
