var el = document.getElementById('placeholder')
el.innerHTML = "Amazing! You're serving static assets."
