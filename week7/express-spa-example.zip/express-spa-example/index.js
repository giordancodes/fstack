var express = require('express');
var app = express();

// Serve your API assets here. You'll need to include the post route file.


// Serve your static assets here. You'll need to use express.static middleware.


// If none of the above matches, serve public/index.html.


app.listen(8080);
