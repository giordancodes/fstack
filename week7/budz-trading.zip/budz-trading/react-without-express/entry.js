var React = require('react');
var ReactDOM = require('react-dom');

// Include your React components like this:
var App = require('./components/app');

ReactDOM.render(<App />, document.getElementById("placeholder"));
