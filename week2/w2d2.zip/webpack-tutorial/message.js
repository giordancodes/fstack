module.exports = "Webpack is working with multiple files and live reloading and stuff!"
