var message = require("./message");

document.getElementById("placeholder").innerHTML = message;
